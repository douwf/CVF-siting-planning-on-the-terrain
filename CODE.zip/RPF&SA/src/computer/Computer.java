package computer;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Stack;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Computer extends JFrame{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Computer com = new Computer();
		com.ComputerFrame();

	}
	String input="" ;
	int num = 0;
	int s1 = 0;
	String key[] = {"1","2","3","4","5","6","7","8","9","+","0","-","/","=","����"};
	JButton jb[];
	JLabel jl1 = new JLabel();
	Stack<String> stack = new Stack<String>(); 
	public void ComputerFrame() {
		
		//String key[] = {"1","2","3","4","5","6","7","8","9","+","0","-","/","=","����"};
		
		JFrame computer = new JFrame("������");
		
		computer.setBounds(200, 200,300, 440);
		computer.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//computer.setVisible(true);
		computer.setLayout(new BorderLayout());
		
		//JLabel jl1 = new JLabel();
		JPanel jp1 = new JPanel();
		JPanel jp2 = new JPanel();
		jp2.setSize(300,100);
		//jl1.setBounds(200, 200, 300,100 );
	    jp2.add(jl1);
		jb = new JButton[key.length];

		jp1.setLayout(new GridLayout(5,3,0,0));
		for(int i = 0;i<key.length;i++) {
			jb[i] = new JButton(key[i]);
			jp1.add(jb[i]);
			jb[i].addActionListener(new deal());
			//jp1.add(jb[i]);
		}
		
		computer.add(jp2,BorderLayout.NORTH);
		computer.add(jp1,BorderLayout.CENTER);
		computer.setVisible(true);
	}
	class deal implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			String command = e.getActionCommand();
		
				if(command.equals("+")||command.equals("*")||command.equals("-")||command.equals("/")) {
					input+=" "+command+" ";
					jl1.setText(input);
				}
				else if(command.equals("����")) {
					input = " ";
					jl1.setText(input);
					
					
				}
				else if(command.equals("=")) {
					
					input+="="+compute(input);//����������Ⱥű����������compute����
					jl1.setText(input);
				}
				else {
					input+=command;
					jl1.setText(input);
				}
				
			
			
		}
        //�������������ʽ
		private String compute(String input) {			
			// TODO Auto-generated method stub
			int result = 0;
			ArrayList<String> list = new ArrayList<>();
			String str[];
			str = input.split(" ");
			
			for(int i = 0;i<str.length;i++) {
				list.add(str[i]);
			}
			ArrayList<String> newlist = CenToFinal(list);
			result = opera(newlist);
			return String.valueOf(result);
			
		}
        //�����׺ʽ
		private int opera(ArrayList<String> newlist) {
			// TODO Auto-generated method stub
			Stack<String> stack1 = new Stack<String>();
			int result = 0;
			for(int i = 0;i<newlist.size();i++) {
				if(isNumeric(newlist.get(i))){//�������־ͽ����ַ�ѹ��ջ��
					stack1.push(newlist.get(i));
				}
				else {//���������������
					int second = Integer.parseInt(stack1.pop());
					int first = Integer.parseInt(stack1.pop());
					if(newlist.get(i).equals("+")) {
						result = first+second;
						
					}
					else if(newlist.get(i).equals("-")) {
						result = first-second;
						
					}
					else if(newlist.get(i).equals("*")) {
						result = first*second;
						
					}
					else if(newlist.get(i).equals("/")) {
						result = first/second;
						
					}
					stack1.push(String.valueOf(result));//��������ѹ��ջ��
				}
			}
			return result;
		}
        //����׺����ʽת��Ϊ��׺����ʽ
		private ArrayList<String> CenToFinal(ArrayList<String> list) {
			// TODO Auto-generated method stub
			ArrayList<String> list1 = new ArrayList<>();
			//Stack<String> stack = new Stack<String>(); 
			for(int i = 0;i<list.size();i++) {
				if(isNumeric(list.get(i))) {
					list1.add(list.get(i));
					continue;
				}
				//���ַ�
				if(isPriority(list.get(i))) {//���ȼ�����ջ��Ԫ�����ȼ��ͽ��÷�����ջ
					//Stack<String> stack = new Stack<String>(); 
					stack.push(list.get(i));
				}
				else {
					while(!stack.isEmpty()) {//�����ȼ�����ջ��Ԫ�ؾͽ�ջ��Ԫ�����μ���list1��
						list1.add(stack.pop());
					}
					
					stack.push(list.get(i));
				}
			}
			while(!stack.isEmpty()) {//��ջ��ʣ��Ԫ�ؼ���list1��
				list1.add(stack.pop());
			}
			return list1;
		}
		//�ж����ȼ�
        private boolean isPriority(String a) {
			// TODO Auto-generated method stub
        	if(stack.isEmpty()) {
        		return true;
        	}
        	String top = stack.peek();
        	if(top.equals("*")||top.equals("/")) {
        		if(a.equals("+")||a.equals("-"))
        			return false;
        		else{
        			return true;
        		}
        	}
        	else {
        		if(top.equals("+")||top.equals("-"))
        			
        		    return true;
			
        	}
        	return true;
		}

		//�ж�һ���ַ��Ƿ�Ϊ����
		private boolean isNumeric(String b) {
			// TODO Auto-generated method stub
			for (int i = b.length();--i>=0;){  
			    if (!Character.isDigit(b.charAt(i))){
			       return false;//��������
			    }
			}
			return true;

			//return false;
		}
		
	}
	

}
