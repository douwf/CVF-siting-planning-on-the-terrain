package myvoronoi;

import java.awt.Point;
import java.awt.Polygon;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.swing.LayoutFocusTraversalPolicy;

import experiment1.Compute;
import experiment1.Dealdata;
import experiment1.Extrat_1000;
import experiment1.K_cluster;
import experiment1.Sort;
import experiment1.TerrainFeature;

public class PartitionFilter_1000 {

	public static int M = 1000,N = 1000;
	private static List<List<Integer>> clusters = new ArrayList<List<Integer>>();
	public static List<float[]> center = new ArrayList<float[]>();//��������
	public static float[][] demdata = new float[M][N];
	
	private static int initialSize = 10000;     // Size of initial triangle
	
	public static ArrayList<Polygon> polygons = new ArrayList<Polygon>();//���ɵ�̩ɭ�����
	
	private static List<List<Integer>> regionpoints = new ArrayList<List<Integer>>();//���䵽����������ӵ�
	
	public static List<List<Integer>> regionviewshed = new ArrayList<List<Integer>>();//���������Ϣ
	
	public static List<List<Integer>> pointInRegion = new ArrayList<List<Integer>>();//ӳ�䵽�������ӵ�
	
	public static int d = 0,l = 0;
	public static int threshold = 1;
	public static int number = 18;
	public static float re = 5;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		long timel = System.currentTimeMillis();
		//��ȡdem����
	    demdata = Dealdata.ReadData();
	    
	    ReadClusters();
		//����dem������ѡ����������
		List<int[]> feature = new ArrayList<int[]>();
		for(int i = 0;i < clusters.size();i++) {
			for(int j = 2;j < clusters.get(i).size();j+=2) {
				int[] co = new int[2];
				co[0] = clusters.get(i).get(j);
				co[1] = clusters.get(i).get(j+1);
				feature.add(co);
			}
		}
		
		
		//���ݵ�����������о��࣬�õ���������
		//clusters = KM(feature);
		//�Ѿ������ķ���һ����ά������
		int[][] center1 = new int[clusters.size()+3][2];
		for(int i = 0;i < clusters.size();i++) {
			center1[i][0] = clusters.get(i).get(0);
			center1[i][1] = clusters.get(i).get(1);
		}
		//�ѳ��������ε�������Ҳ����������ĵ���
		center1[clusters.size()][0] = -initialSize;center1[clusters.size()][1] = -initialSize;
		center1[clusters.size()+1][0] = initialSize;center1[clusters.size()+1][1] = -initialSize;
		center1[clusters.size()+2][0] = 0;center1[clusters.size()+2][1] = initialSize;
		//���ݾ�����������̩ɭ�����
		polygons = Thiessen.constructThiessen(center1);
		
		//����ÿ��������������������򣬲����������������㵽��������
		regionpoints = mapPointsToRegions(feature);
		//��ÿ�������е��ӵ��������
		Sort(feature);
		int c = 0;
		for(int i = 0;i < pointInRegion.size();i++) {
			for(int j = 0;j < pointInRegion.get(i).size();j+=3) {
				c++;
			}
		}
		System.out.println(c);
		//�����������������й���
		filter();
		
		long time2 = System.currentTimeMillis();
		//������
		for(int i = 0;i < pointInRegion.size();i++) {
			for(int j = 0;j < pointInRegion.get(i).size();j+=3) {
				System.out.print("{"+pointInRegion.get(i).get(j)+","+pointInRegion.get(i).get(j+1)+"}"+",");
			}

		}
		System.out.println(time2-timel);
	}


	private static void filter() {
		// TODO Auto-generated method stub
		int flag = 0;
		while(flag == 0) {//���ÿ����δ������ֵҪ��
			if(pointInRegion.get(d).size()/3 > threshold) {
				//����d��Ҷ�ӽڵ��λ��
				int m = pointInRegion.get(d).size()-3;
				int n = pointInRegion.get(d).size()-2;
				int numsub = pointInRegion.get(d).size()-1;
				//����d��Ҷ�ӽڵ��Ԫ��ֵ
				int x1 = pointInRegion.get(d).get(m);
				int y1 = pointInRegion.get(d).get(n);
				int num1 = pointInRegion.get(d).get(numsub);
				//������d�е�Ҷ�ӽڵ�Ӹô����Ƴ�
				pointInRegion.get(d).remove(numsub);
				pointInRegion.get(d).remove(n);
				pointInRegion.get(d).remove(m);
				loop:for(int j = 1;j <= pointInRegion.size()-1;) {
					
					//��������d�е�Ҷ�ӽڵ�������l�е���������
					int dINl = 0;
					l = (d+j)%(pointInRegion.size());
					for(int i = 0;i < regionviewshed.size();i++) {
						if(regionviewshed.get(i).get(0)==x1&&regionviewshed.get(i).get(1)==y1) {
							dINl = regionviewshed.get(i).get(l+2);
							break;
						}
					}
					if(dINl == 0) {
						j++;
						continue;
					}
					for(int k = 0;k < pointInRegion.get(l).size();k+=3) {
						if(pointInRegion.get(l).get(k+2)<dINl) {
							pointInRegion.get(l).add(k,x1);
							pointInRegion.get(l).add(k+1,y1);
							pointInRegion.get(l).add(k+2,dINl);
							d = l;
							if((k+3) == pointInRegion.get(l).size()) {
								pointInRegion.get(l).remove(k+2);
								pointInRegion.get(l).remove(k+1);
								pointInRegion.get(l).remove(k);
							}
							break loop;
						}
					}
					j++;
				}
			}
			else d = (d+1)%pointInRegion.size();
			
			for(int i = 0;i < pointInRegion.size();i++) {
				for(int j = 0;j < pointInRegion.get(i).size();j++) {
					System.out.print(pointInRegion.get(i).get(j)+" ");
				}
				System.out.println();
			}
			
			for(int i = 0;i < pointInRegion.size();i++) {
				if(pointInRegion.get(i).size()/3 > threshold) {
					break;
				}
				if(i == pointInRegion.size()-1) {
					flag = 1;
				}
			}
		}
		
		
	}

	private static void Sort(List<int[]> feature) {
		// TODO Auto-generated method stub
		for(int i = 0;i < pointInRegion.size();i++) {
			for(int j = 0;j < pointInRegion.get(i).size()-3;j+=3) {
				for(int k = 0;k < pointInRegion.get(i).size()-3-j;k+=3) {
					if(pointInRegion.get(i).get(j+2) > pointInRegion.get(i).get(k+2)) {//����������Ľ�������
		
						swap(j,j+1,j+2,k,k+1,k+2,pointInRegion.get(i));
					}
				}
			}
		}
	}

	private static void swap(int x1, int y1, int num1, int x2, int y2, int num2, List<Integer> list) {
		// TODO Auto-generated method stub
		int tempx = list.get(x1),tempy = list.get(y1),tempnum = list.get(num1);
		list.set(x1, list.get(x2));
		list.set(y1, list.get(y2));
		list.set(num1, list.get(num2));
		list.set(x2, tempx);
		list.set(y2, tempy);
		list.set(num2, tempnum);
	}

	private static List<List<Integer>> mapPointsToRegions(List<int[]> feature) {
		// TODO Auto-generated method stub
		Compute compute = new Compute();
		for(int i = 0;i < feature.size();i++) {
			regionviewshed.add(new ArrayList<Integer>());
			regionviewshed.get(i).add(feature.get(i)[0]);
			regionviewshed.get(i).add(feature.get(i)[1]);
			int[][] view = compute.computeView(feature.get(i)[0], feature.get(i)[1], demdata);
			//List<Integer> singlefeatureviewshed = new ArrayList<Integer>();
			//singlefeatureviewshed.addAll(viewshed.get(i));
			for(int j = 0;j < polygons.size();j++) {
				int count = 0;
				for(int s = 0;s < view.length;s++) {
					for(int t = 0;t < view[0].length;t++) {
						if(view[s][t]==1) {
							int x = s;
							int y = t;
							Point o = new Point(x, y);
							if(polygons.get(j).contains(o)) {
								count++;
							}
						}
						
					}
					
				}
				regionviewshed.get(i).add(count);
			}
		}
		for(int i = 0;i < polygons.size();i++) {
			pointInRegion.add(new ArrayList<Integer>());
		}
		for(int i = 0;i < feature.size();i++) {
			int max = 0;
			int locate = -1;
			for(int j = 2;j < regionviewshed.get(i).size();j++) {
				if(regionviewshed.get(i).get(j)>max) {
					max = regionviewshed.get(i).get(j);
					locate = j-2;
				}
			}
			pointInRegion.get(locate).add(feature.get(i)[0]);
			pointInRegion.get(locate).add(feature.get(i)[1]);
			pointInRegion.get(locate).add(max);
		}

		return pointInRegion;
	}
	
	public static List<List<Integer>> KM(List<int[]> point2) {
		// TODO Auto-generated method stub
		//��ʼ�������point��ѡ��40������Ϊ��ʼ��������
		for(int i = 0;i < number;i++) {
			int temp =  (int) (Math.random()*point2.size());
			for(int j = 0;j < point2.size();j++) {
				if(temp == j) {
					float[] p = new float[3];
					p[0] = point2.get(j)[0];
					p[1] = point2.get(j)[1];
					p[2] = demdata[point2.get(j)[0]][point2.get(j)[1]];
					
					center.add(p);
					//�Ѵ����ķ���ÿ�������λ
//					clusters.add(new ArrayList<Integer>());
//					clusters.get(i).add(point.get(j)[0]);
//					clusters.get(i).add(point.get(j)[1]);
				}
			}
		}
		
		//K_means
		
		
		
			
			
			KMeans(demdata,point2);
			
			for(int i = 0;i < clusters.size();) {
				if((clusters.get(i).get(0)==0)&&(clusters.get(i).get(1)==0)) {
					clusters.remove(i);
					
				}
				else i++;
			}
		
		
		//���
		for(int i = 0;i < clusters.size();i++) {
			for(int  j = 0;j < clusters.get(i).size();j+=2) {
				System.out.print(clusters.get(i).get(j)+" "+clusters.get(i).get(j+1)+",");
			}
			System.out.println();
		}
		return clusters;
	}
	

	private static void KMeans(float[][] demdata, List<int[]> point) {
		// TODO Auto-generated method stub
		//���������Ĳ��ٸı�ʱ������ֹ
		List<List<Integer>> cluster = new ArrayList<List<Integer>>();
		int flag = 0;
		while(flag < 1000) {
			cluster.clear();
			for(int a = 0;a < center.size();a++) {
				cluster.add(new ArrayList<Integer>());
				//cluster.get(a).add((int)center.get(a)[0]);
				//cluster.get(a).add((int)center.get(a)[1]);
			}
			//��point�����е㶼��ÿ�������Ľ��бȽ�
			for(int i = 0;i < point.size();i++) {
				int row = point.get(i)[0];
				int col = point.get(i)[1];
				float min = comDistence((float)row,(float)col,demdata[row][col],center.get(0)[0],center.get(0)[1],center.get(0)[2]);
				int tempj = 0;
				for(int j = 0;j < center.size();j++) {
					//����õ㵽���ĵľ���
					float distence = comDistence((float)row,(float)col,demdata[row][col],center.get(j)[0],center.get(j)[1],center.get(j)[2]);
					if(distence<min) {
						min = distence;
						tempj = j;
					}
				}
				cluster.get(tempj).add(row);
				cluster.get(tempj).add(col);
			}
			//����ÿһ�ָ���������
			for(int x = 0;x < cluster.size();x++) {
				int sumrow = 0,sumcol = 0;
				float cenrow = 0,cencol = 0,sumheight = 0,cenheight = 0;
				for(int y = 2;y < cluster.get(x).size();y+=2) {
					sumrow += cluster.get(x).get(y);
					sumcol += cluster.get(x).get(y+1);
					sumheight += demdata[cluster.get(x).get(y)][cluster.get(x).get(y+1)];
				}
				cenrow = (float)sumrow/(float)(cluster.get(x).size()/2-1);
				cencol = (float)sumcol/(float)(cluster.get(x).size()/2-1);
				cenheight = sumheight/(float)(cluster.get(x).size()/2-1);
				float[] newcen = new float[3];
				newcen[0] = cenrow;
				newcen[1] = cencol;
				newcen[2] = cenheight;
				center.set(x, newcen);
			}
			flag++;
		}
		for(int i = 0;i < cluster.size();i++) {
			clusters.add(new ArrayList<Integer>());
			//�Ѵ����ĺʹ��ڵ㶼���뵽��������
			clusters.get(i).add((int)center.get(i)[0]);
			clusters.get(i).add((int)center.get(i)[1]);
			for(int j = 2;j < cluster.get(i).size();j++) {
				clusters.get(i).add(cluster.get(i).get(j));
			}
		}
	}

	private static float comDistence(float row, float col, float h1, float i, float j, float h2) {
		// TODO Auto-generated method stub
		float distence = (float) Math.sqrt((row-i)*re*(row-i)*re+(col-j)*re*(col-j)*re+(h1-h2)*(h1-h2));
		return distence;
	}
	
	public static void ReadClusters() {
		// TODO Auto-generated method stub
		try {
			Scanner scanner = new Scanner(new File("F:\\experimentData\\clusters_1ex_35.txt"));
			int i = 0;
			while(scanner.hasNextLine()) {
				String line  = scanner.nextLine();
				String[] oneline = line.split(",");
				clusters.add(new ArrayList<Integer>());
				for(int j = 0;j < oneline.length;j++) {
					clusters.get(i).add(Integer.parseInt(oneline[j]));
				}
				i++;
						
			}
			scanner.close();
		}
		catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		
	}

}
