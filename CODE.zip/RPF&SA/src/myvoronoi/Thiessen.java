package myvoronoi;

import java.awt.Polygon;
import java.awt.color.ICC_ColorSpace;
import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import javax.naming.ldap.ExtendedRequest;
import javax.naming.ldap.ExtendedResponse;
import javax.net.ssl.ExtendedSSLSession;

import org.omg.PortableServer.ServantActivator;

public class Thiessen extends Polygon{

	private static int initialSize = 10000;     // Size of initial triangle
    
    public static ArrayList<ArrayList<Integer>> triangles = new ArrayList<ArrayList<Integer>>();//delauny������
    public static ArrayList<ArrayList<Integer>> aftercodetriangles = new ArrayList<ArrayList<Integer>>();//��Ź����������
    public static ArrayList<ArrayList<Integer>> pointTotriangles = new ArrayList<ArrayList<Integer>>();//���������ӵ�������
    public static ArrayList<ArrayList<Integer>> newpointTotriangles = new ArrayList<ArrayList<Integer>>();//�����ĸ��������ӵ�������
    public static ArrayList<ArrayList<Float>> thiessens = new ArrayList<ArrayList<Float>>();//��Ÿ���̩ɭ�����
    public static ArrayList<ArrayList<Integer>> boundrypoint = new ArrayList<ArrayList<Integer>>();//����������߽��
    public static ArrayList<Polygon> polys = new ArrayList<Polygon>();
    
    
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[][] point = {{45,2},{93,9},{110,16},{20,103},{66,6},{9,96},{97,3},{8,111},{8,126},{27,62},
				{12,36},{14,117},{34,113},{15,77},{38,83},{97,35},{44,108},{92,14},{6,69},{11,141},{85,11},
				{45,131},{24,83},{90,21},{10,55},{35,96},{115,4},{3,83},{87,4},{55,111},{24,117},{79,4},{49,2},
				{75,8},{52,2},{104,2},{-initialSize,-initialSize},{initialSize,-initialSize},{0,initialSize}};
		//����Delaunny������
		int count = 0;
		triangles = DelaunyOld.d(point);
		for(int i = 0;i < triangles.size();) {
			loop:for(int j = 0;j < triangles.get(i).size();j+=2) {
				for(int k = 0;k < triangles.get(i).size();k+=2) {
					if((j!=k)&&((triangles.get(i).get(j).intValue()==triangles.get(i).get(k).intValue())&&(triangles.get(i).get(j+1).intValue()==triangles.get(i).get(k+1).intValue()))) {
						triangles.remove(i);
						break loop;
					}
				}
				if((j+2)==triangles.get(i).size()) i++;
			}
		
		}
        for(int i = 0;i < triangles.size();i++) {
        	System.out.println(triangles.get(i).get(0)+" "+triangles.get(i).get(1)+","+triangles.get(i).get(2)
        			+" "+triangles.get(i).get(3)+","+triangles.get(i).get(4)+" "+triangles.get(i).get(5));
        	count++;
        }
    	System.out.println(count);
    	
    	//����Delaunny����������̩ɭ�����
    	thiessen(point);
    	for(int i = 0;i < thiessens.size();i++) {
    		for(int j = 0;j < thiessens.get(i).size();j+=2) {
    			System.out.print(thiessens.get(i).get(j)+" "+thiessens.get(i).get(j+1)+",");
    		}
    		System.out.println();
    	}
        poly();
    }
	
	
	public static ArrayList<Polygon> constructThiessen(int[][] point){
		//����Delaunny������
		int count = 0;
		triangles = DelaunyOld.d(point);
		for(int i = 0;i < triangles.size();) {
			loop:for(int j = 0;j < triangles.get(i).size();j+=2) {
				for(int k = 0;k < triangles.get(i).size();k+=2) {
					if((j!=k)&&((triangles.get(i).get(j).intValue()==triangles.get(i).get(k).intValue())&&(triangles.get(i).get(j+1).intValue()==triangles.get(i).get(k+1).intValue()))) {
						triangles.remove(i);
						break loop;
					}
				}
				if((j+2)==triangles.get(i).size()) {i++;break loop;}
			}
		
		}
        for(int i = 0;i < triangles.size();i++) {
        	System.out.println(triangles.get(i).get(0)+" "+triangles.get(i).get(1)+","+triangles.get(i).get(2)
        			+" "+triangles.get(i).get(3)+","+triangles.get(i).get(4)+" "+triangles.get(i).get(5));
        	count++;
        }
    	System.out.println(count);
    	
    	//����Delaunny����������̩ɭ�����
    	thiessen(point);
    	for(int i = 0;i < thiessens.size();i++) {
    		for(int j = 0;j < thiessens.get(i).size();j+=2) {
    			System.out.print(thiessens.get(i).get(j)+" "+thiessens.get(i).get(j+1)+",");
    		}
    		System.out.println();
    	}
        poly();
		return polys;
		
	}

	private static void poly() {
		// TODO Auto-generated method stub
		//��thessien�еĵ��Ϲ��ɱ߷���polys��
		for(int i = 0;i < thiessens.size()-3;i++) {
			Polygon polygon = new Polygon();
			
			for(int j = 0;j < thiessens.get(i).size();j+=2) {
				float x = thiessens.get(i).get(j);
				float y = thiessens.get(i).get(j+1);
				polygon.addPoint((int)x, (int)y);
				
			}
			polys.add(polygon);
		
		}
	}

	/**
	 * �������ɵ���������������̩ɭ�����
	 * @param point 
	 */
	private static void thiessen(int[][] point) {
		// TODO Auto-generated method stub
		//�����������α�ź����aftercodetriangles
		for(int i = 0;i < triangles.size();i++) {
			aftercodetriangles.add(new ArrayList<Integer>());
			for(int j = 0;j < triangles.get(i).size();j++) {
				aftercodetriangles.get(i).add(triangles.get(i).get(j));
			}
			
		}
		for(int i = 0;i < point.length;i++) {
			//�ҳ��뵱ǰ�����ӵ����������Σ�����¼���б���
			int tempx = (int)point[i][0];
			int tempy = (int)point[i][1];
			pointTotriangles.add(new ArrayList<Integer>());
			pointTotriangles.get(i).add(tempx);
			pointTotriangles.get(i).add(tempy);
			for(int j = 0;j < aftercodetriangles.size();j++) {
				for(int k = 0;k < aftercodetriangles.get(j).size();k+=2) {//ֻҪ�����������������㣬�Ͱ���������μ��뵽�������б���
					if(tempx == aftercodetriangles.get(j).get(k)&&tempy == aftercodetriangles.get(j).get(k+1)) {
				
						for(int l = 0;l < aftercodetriangles.get(j).size();l+=2) {
							if(l!=k) {
								pointTotriangles.get(i).add(aftercodetriangles.get(j).get(l));
								pointTotriangles.get(i).add(aftercodetriangles.get(j).get(l+1));
							}
						}
					}
				}
			}
		}
		int count = 0;
   		for(int i = 0;i < point.length;i++) {
			int x = (int)point[i][0];
			int y = (int)point[i][1];
			
			newpointTotriangles.add(new ArrayList<Integer>());
			newpointTotriangles.get(i).add(x);
			newpointTotriangles.get(i).add(y);
			//�ҳ�һ�������ε���ʼ�ߺ���ֹ��
			int startx = pointTotriangles.get(i).get(2);
			int starty = pointTotriangles.get(i).get(3);
			int endx = pointTotriangles.get(i).get(4);
			int endy = pointTotriangles.get(i).get(5);
			newpointTotriangles.get(i).add(startx);
			newpointTotriangles.get(i).add(starty);
			newpointTotriangles.get(i).add(endx);
			newpointTotriangles.get(i).add(endy);
			//�Ƴ��Ѿ�����ĵ����б��ĵ�
			pointTotriangles.get(i).remove(2);
			pointTotriangles.get(i).remove(2);
			pointTotriangles.get(i).remove(2);
			pointTotriangles.get(i).remove(2);
			for(int k = 2;k < pointTotriangles.get(i).size();k+=2) {
				if(pointTotriangles.get(i).get(k)==startx&&pointTotriangles.get(i).get(k+1)==starty)break;
				if((k+2)==pointTotriangles.get(i).size()) {
					int tempx = startx,tempy = starty;
					startx = endx;
					starty = endy;
					endx = tempx;
					endy = tempy;
				}
			}
			
			for(int j = 2;j < pointTotriangles.get(i).size();) {
				
				if(pointTotriangles.get(i).get(j)==startx&&pointTotriangles.get(i).get(j+1)==starty
						||pointTotriangles.get(i).get(j+2)==startx&&pointTotriangles.get(i).get(j+3)==starty) {
					
					if(pointTotriangles.get(i).get(j)!=startx||pointTotriangles.get(i).get(j+1)!=starty) {
						startx = pointTotriangles.get(i).get(j);
						starty = pointTotriangles.get(i).get(j+1);
					}
					else if(pointTotriangles.get(i).get(j+2)!=startx||pointTotriangles.get(i).get(j+3)!=starty) {
						startx = pointTotriangles.get(i).get(j+2);
						starty = pointTotriangles.get(i).get(j+3);
					}
					newpointTotriangles.get(i).add(pointTotriangles.get(i).get(j));
					newpointTotriangles.get(i).add(pointTotriangles.get(i).get(j+1));
					newpointTotriangles.get(i).add(pointTotriangles.get(i).get(j+2));
					newpointTotriangles.get(i).add(pointTotriangles.get(i).get(j+3));
					
					pointTotriangles.get(i).remove(j);
					pointTotriangles.get(i).remove(j);
					pointTotriangles.get(i).remove(j);
					pointTotriangles.get(i).remove(j);
					if(pointTotriangles.get(i).size()!=2) {
						
						for(int l = 2;l < pointTotriangles.get(i).size();l+=2) {
							if(pointTotriangles.get(i).get(l)==startx&&pointTotriangles.get(i).get(l+1)==starty) break;
							if((l+2) == pointTotriangles.get(i).size()) {
								ArrayList<Integer> temp = new ArrayList<Integer>();
								temp.addAll(newpointTotriangles.get(i));			
								
								for(int d = 2;d < newpointTotriangles.get(i).size();) {
									newpointTotriangles.get(i).remove(d);
								}
								int u = 2;
								for(int f = temp.size();f > 2;f-=4) {
									int x1 = temp.get(f-4),y1 = temp.get(f-3);
									int x2 = temp.get(f-2),y2 = temp.get(f-1);
									newpointTotriangles.get(i).add(u++,x1);
									newpointTotriangles.get(i).add(u++,y1);
									newpointTotriangles.get(i).add(u++,x2);
									newpointTotriangles.get(i).add(u++,y2);
								}
//								boundrypoint.add(new ArrayList<Integer>());
//								boundrypoint.get(count).add(temp.get(0));
//								boundrypoint.get(count).add(temp.get(1));
//								count++;
								int tempx = startx,tempy = starty;
								startx = endx;
								starty = endy;
								endx = tempx;
								endy = tempy;
							}
						}
					}
					j = 2;
				}
				else j+=4;
			}
//			if(newpointTotriangles.get(i).size()>10) {
//				int u = 0,v = 0;
//				for(int j = 2;j < newpointTotriangles.get(i).size();j+=2) {
//					if(newpointTotriangles.get(i).get(2)==newpointTotriangles.get(i).get(j)
//							&&newpointTotriangles.get(i).get(3)==newpointTotriangles.get(i).get(j+1)) {
//						u++;
//					}
//					if(newpointTotriangles.get(i).get(4)==newpointTotriangles.get(i).get(j)
//							&&newpointTotriangles.get(i).get(5)==newpointTotriangles.get(i).get(j+1)) {
//						v++;
//					}
//				}
//				if(u%2!=0||v%2!=0) {
//					boundrypoint.add(new ArrayList<Integer>());
//					boundrypoint.get(count).add(x);
//					boundrypoint.get(count).add(y);
//					count++;
//				}
//			}
//			else {
//				boundrypoint.add(new ArrayList<Integer>());
//				boundrypoint.get(count).add(x);
//				boundrypoint.get(count).add(y);
//				count++;
//			}
				
		}
		for(int i = 0;i < newpointTotriangles.size();i++) {
			int commonx = newpointTotriangles.get(i).get(0);
			int commony = newpointTotriangles.get(i).get(1);
			int flag = 0;
			thiessens.add(new ArrayList<Float>());
//			for(int k = 0;k < boundrypoint.size();k++) {//����Ǳ߽��ͱ��
//				if(boundrypoint.get(k).get(0)==commonx&&boundrypoint.get(k).get(1)==commony) {
//					flag = 1;
//				}
//			}
//			if(flag == 1) {
//				thiessens.get(i).add((float) 1.0);
//			}
//			else thiessens.get(i).add((float) 0);
			for(int j = 2;j < newpointTotriangles.get(i).size();j+=4) {
				int x2 = newpointTotriangles.get(i).get(j);
				int y2 = newpointTotriangles.get(i).get(j+1);
				int x3 = newpointTotriangles.get(i).get(j+2);
				int y3 = newpointTotriangles.get(i).get(j+3);
				//����ÿ�������ε����ԲԲ��
				float[] center = computeCircleCenter(commonx,commony,x2,y2,x3,y3);
				thiessens.get(i).add(center[0]);
				thiessens.get(i).add(center[1]);
			}
		}
	}

	private static float[] computeCircleCenter(int a, int b, int c, int d, int e, int f) {
		// TODO Auto-generated method stub
		float x1 = (float)a,y1 = (float)b,x2 = (float)c,y2 = (float)d,x3 = (float)e,y3 = (float)f;
		float[] center = new float[2];
		float c1= (float) (((y2-y1)*(y3*y3-y1*y1+x3*x3-x1*x1)-(y3-y1)*(y2*y2-y1*y1+x2*x2-x1*x1))/(2.0*((x3-x1)*(y2-y1)-(x2-x1)*(y3-y1))));
		float c2=(float) (((x2-x1)*(x3*x3-x1*x1+y3*y3-y1*y1)-(x3-x1)*(x2*x2-x1*x1+y2*y2-y1*y1))/(2.0*((y3-y1)*(x2-x1)-(y2-y1)*(x3-x1))));
		center[0] = c1;
		center[1] = c2;
		return center;
	}


	

}
