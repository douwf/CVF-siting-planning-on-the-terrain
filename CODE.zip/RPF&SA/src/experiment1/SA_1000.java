package experiment1;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.DatabaseMetaData;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import javax.print.attribute.standard.PrinterMessageFromOperator;

public class SA_1000 {

	public static int M = 1000,N = 1000;
	public static float[][] demdata = new float[M][N];
	public static int number = 35;
	public static int T = 100;//��ʼ�¶�
	public static double Tmin = 1e-8;//��ֹ�¶�
	public static int k = 10;// �����Ĵ���
	public static List<int[]> feature = new ArrayList<int[]>();
	public static int[][] finalresult = new int[number][2];//�ö�ά������������µ��ӵ�
	public static float eur = 1000,re = 5,delta = (float) 0.9;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//��ȡdem����
		readdata();
		//��ȡ����������
		feature = Extrat_1000.extract();
		//�������number���ӵ���Ϊ��ʼ��
		for(int i = 0;i < number;i++) {
			int ram = (int) (Math.random()*(feature.size()));
			finalresult[i][0] = feature.get(ram)[0];
			finalresult[i][1] = feature.get(ram)[1];
		}
		//���ݳ�ʼ�⿪ʼģ���˻��㷨
		Simulatedannealing();
	}
	
	
	
	private static void Simulatedannealing() {
		// TODO Auto-generated method stub
		//��������
		float coverage = computeallview(finalresult);
		int[][] templocation = new int[number][2];
		for(int i = 0;i < number;i++) {
			templocation[i][0] = finalresult[i][0];
			templocation[i][1] = finalresult[i][1];
		}
			
		System.out.print(coverage);
		float newcoverage = 0;
		double t = T;
		
		while (t > Tmin) 
		{
			System.out.println(t);
            for(int i = 0;i < k;i++)
            {
            	for(int j = 0;j < finalresult.length;j++)
            	{

            		int flag = 0;
            		int r = (int) (Math.random()*feature.size());
        			int tempx = feature.get(r)[0];
        			int tempy = feature.get(r)[1];
            		while(flag!=1) {
            			
            			if(distence(tempx,tempy,demdata[tempx][tempy],templocation[j][0],templocation[j][1],demdata[templocation[j][0]][templocation[j][1]])<eur) {
            				templocation[j][0] = tempx;
                    		templocation[j][1] = tempy;
                    		flag = 1;
            			}
            			else {
            				r = (int) (Math.random()*feature.size());
                		    tempx = feature.get(r)[0];
                			tempy = feature.get(r)[1];
						}
            		}
            		
            		
               		//System.out.println(location[j][0]+" "+location[j][1]);
            		
            	}
            	newcoverage = computeallview(templocation);
        		if(newcoverage>coverage) 
        		{
        			for(int s = 0;s < number;s++) {
                		finalresult[s][0] = templocation[s][0];
                		finalresult[s][1] = templocation[s][1];
            		}
        			coverage = newcoverage;
        			System.out.println(coverage);
        		}
        		else {
        			double p = 1 / (1 + Math.exp(-(newcoverage - coverage) / T));
                    if (Math.random() < p)
                    {
                    	for(int s = 0;s < number;s++) {
                    		finalresult[s][0] = templocation[s][0];
                    		finalresult[s][1] = templocation[s][1];
                		}
                    	coverage = newcoverage;
                    }
        		}	
            }
            
            t = t * delta;
        }
		
	}
	
	
	private static float computeallview(int[][] temp) {
		
		// TODO Auto-generated method stub
		int count = 0;
		float percent = 0;
		int[][] allview = new int[M][N];
		Compute compute = new Compute();
		for(int i = 0;i < temp.length;i++) {
			int[][] tempview = compute.computeView(temp[i][0],temp[i][1], demdata);
			for(int j = 0;j < allview.length;j++) {
				for(int k = 0;k < allview[0].length;k++) {
					if(tempview[j][k] == 1) {
						allview[j][k] = 1;
					}
				}
			}
		}
		for(int i = 0;i < allview.length;i++) {
			for(int j = 0;j < allview[0].length;j++) {
				if(allview[i][j] == 1) {
					count++;
				}
			}
		}
		percent = (float)count/(float)(M*N);
		return percent;
	}


	private static float distence(float row, float col, float h1, float i, float j, float h2) {
		// TODO Auto-generated method stub
		float distence = (float) Math.sqrt((row-i)*re*(row-i)*re+(col-j)*re*(col-j)*re+(h1-h2)*(h1-h2));
		return distence;
	}


	private static void readdata() {
		// TODO Auto-generated method stub
		//float[][] demdata = new float[718][1483];
        try
        {
            //Scanner scanner = new Scanner(new File("f://writerGDAL_aa.txt"));
        	Scanner scanner = new Scanner(new File("F:\\experimentData\\1000_1_ex.txt"));
            int i = 0;
            while(scanner.hasNextLine())
            {
                String line = scanner.nextLine();
                
                String[] oneline = line.split(",");

                for(int j = 0; j < oneline.length; j++)
                {
                    demdata[i][j] = Float.parseFloat(oneline[j]);
                }
                
                i++;
            }
            scanner.close();
            
        }
        catch(FileNotFoundException e)
        {
            e.printStackTrace();
        }
		//return demdata;
  
	}

}
