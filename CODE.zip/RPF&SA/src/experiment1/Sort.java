package experiment1;

import java.util.ArrayList;
import java.util.List;

public class Sort {
    

	public static List<List<Float>> clusterswithfitness = new ArrayList<List<Float>>();

	public static List<List<Float>> descendSort(List<List<Integer>> clusters, float[][] demdata) {
		// TODO Auto-generated method stub
		//int totaloverlap = 0;
		//List<List<Integer>> clustersaftersort = new ArrayList<List<Integer>>();

		for(int i = 0;i < clusters.size();i++) {
			//int u = compute_V(17,23);
			int[] viewshednum = new int[clusters.get(i).size()/2-1];//�����Ÿô��и��ӵ�Ŀ�����ָ��
			int[] overlapnum = new int[clusters.get(i).size()/2-1];//��Ÿ��ӵ�����������ӵ�Ŀ������ص�
			float[] fitness = new float[clusters.get(i).size()/2-1];//��Ÿ��ӵ������ָ��
			
			clusterswithfitness.add(new ArrayList<Float>());
			clusterswithfitness.get(i).add((float)clusters.get(i).get(0));
			clusterswithfitness.get(i).add((float)clusters.get(i).get(1));
			
			for(int j = 2;j < clusters.get(i).size();j+=2) {
				//�����ӵ�Ŀ�����ָ��
				viewshednum[(j-2)/2] = 
						compute_V(clusters.get(i).get(j),clusters.get(i).get(j+1),demdata);
				//������ӵ���ĳһ���еĿ������ص�
				overlapnum[(j-2)/2] = 
						compute_O(clusters.get(i).get(j),clusters.get(i).get(j+1),clusters.get(i),demdata);
				
				
				clusterswithfitness.get(i).add((float)clusters.get(i).get(j));
				clusterswithfitness.get(i).add((float)clusters.get(i).get(j+1));
				float fit = (float)overlapnum[(j-2)/2]/(float)(viewshednum[(j-2)/2]*viewshednum[(j-2)/2]);
				clusterswithfitness.get(i).add(fit);
				
				
			}
			//�ô��и��ӵ������ָ������fitness[]
			for(int k = 2;k < clusters.get(i).size();k+=2) {
				fitness[(k-2)/2] = (float)overlapnum[(k-2)/2]/(float)(viewshednum[(k-2)/2]*viewshednum[(k-2)/2]);
			}
			

			
			//ð������
			for(int s = 0;s < fitness.length-1;s++) {
				for(int t = 0;t < fitness.length-1-s;t++) {
					if(fitness[t]>fitness[t+1]) {
						Swap(clusterswithfitness.get(i),fitness,t,t+1);
					}
				}
				
			}
			System.out.print(clusters.get(i).get(0)+" "+clusters.get(i).get(1));
			for(int k = 2;k < clusters.get(i).size();k+=2) {
				System.out.print(fitness[(k-2)/2]+" ");
				System.out.print(clusters.get(i).get(k)+" "+clusters.get(i).get(k+1)+",");
			}
			System.out.println();
			
		}
		return clusterswithfitness;
	}

	public static void Swap(List<Float> list, float[] fitness, int s, int t) {
		// TODO Auto-generated method stub
		float temp = 0;
		float row = 0,col = 0,fit = 0;
		temp = fitness[s];
		
		fitness[s] = fitness[t];
		fitness[t] = temp;
		
		row = list.get(s*3+2);
		col = list.get(s*3+3);
		fit = list.get(s*3+4);
		
		list.set(s*3+2, list.get(t*3+2));
		list.set(s*3+3, list.get(t*3+3));
		list.set(s*3+4, list.get(t*3+4));
		
		list.set(t*3+2, row);
		list.set(t*3+3, col);
		list.set(t*3+4, fit);
				
	}

	public static int compute_O(int i, int j, List<Integer> cluster, float[][] demdata) {
		// TODO Auto-generated method stub
		Compute compute = new Compute();
		int[][] view = compute.computeView(i, j, demdata);
		int[][] currentview = new int[view.length][view[0].length];
		for(int u = 0;u < view.length;u++) {
			for(int v = 0;v < view[0].length;v++) {
				currentview[u][v] = view[u][v];
			}
		}
		int count = 0;
		
		for(int k = 2;k < cluster.size();k+=2) {
			int a = cluster.get(k);
			int b = cluster.get(k+1);
			if(a!=i||b!=j) {
				int[][] tempview = compute.computeView(a, b, demdata); 
				for(int x = 0;x < currentview.length;x++)
					for(int y = 0;y < currentview[0].length;y++) {
						if(tempview[x][y] == 1&&currentview[x][y] == 1)
							count++;
					}
			}
		}
		return count;
	}

	public static int compute_V(int i, int j, float[][] demdata) {
		// TODO Auto-generated method stub
		Compute compute = new Compute();
		int[][] view = compute.computeView(i,j, demdata);
		
		int count = 0;
		
		for(int a = 0;a < view.length;a++)
			for(int b = 0;b < view[0].length;b++) {
				if(view[a][b] == 1) {
					count++;
				}
			}
		return count;
	}


}
