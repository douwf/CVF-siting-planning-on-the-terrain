package experiment1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TerrainFeature {

    public static float[][] demdata = new float[123][149];
	public static int[][] VR = new int[123][149];
	
	public static List<int[]> list = new ArrayList<int[]>(); 
	
	public static List<int[]> Extract(){
		// TODO Auto-generated method stub

		//����DEM����
		Dealelevationdata();
		
		//�������߳�����С�߳�
		float average = Compute();
		
		//��ȡ����������
		FeaturePoint(average);
		//int counter = 0;
		for(int i = 0;i < demdata.length;i++) {
			for(int j = 0;j < demdata[0].length;j++) {
				if(VR[i][j]!=0) {
					int[] co = new int[2];
					co[0] = i;
					co[1] = j;
					list.add(co);
				}
				
				
			}
			
		}
		return list;
		
		//System.out.println(counter);
	}

	
	private static float Compute() {
		// TODO Auto-generated method stub
		float max = 0;
		float min = 1000;
		float ave= 0;
		for(int i = 0;i < demdata.length;i++) {
			for(int j = 0;j < demdata[0].length;j++) {
				if(demdata[i][j]>max) max = demdata[i][j];
				if(demdata[i][j]<min) min = demdata[i][j];
			}
		}
		ave = (min+max)/2;
		return ave;
	}


	private static void FeaturePoint(float average) {
		// TODO Auto-generated method stub
		for(int i = 1;i < demdata.length;i++) {
			for(int j = 1;j < demdata[0].length;j++) {
				if(i!=0&&j!=0&&i!=demdata.length-1&&j!=demdata[0].length-1) {
					float center = demdata[i][j],N = demdata[i-1][j],S = demdata[i+1][j],
							W = demdata[i][j-1],E = demdata[i][j+1],
							NE = demdata[i-1][j+1],SE = demdata[i+1][j+1],
							WN = demdata[i-1][j-1],WS = demdata[i+1][j-1];
					if((W-center)*(E-center)>0) {
						if(E>center&&center>average) VR[i][j] = -1;
						if(E<center&&center>average) VR[i][j] = 1;
					}
					else if((S-center)*(N-center)>0) {
						if(N>center&&center>average) VR[i][j] = -1;
						if(N<center&&center>average) VR[i][j] = 1;
					}
//					if((E>center&&N<center)||(E<center&&N>center)){
//						VR[i][j] = 2;
//					}
					if(center>W&&center>N&&center>E&&center>S&&center>NE
							&&center>SE&&center>WN&&center>WS&&center>average) {
						VR[i][j] = 3;
					}
					if(center<W&&center<N&&center<E&&center<S&&center<NE
							&&center<SE&&center<WN&&center<WS&&center<500) {
						VR[i][j] = -2;
					}
//					if(center==W&&center==N&&center==E&&center==S&&center==NE
//							&&center==SE&&center==WN&&center==WS) {
//						VR[i][j] = 4;
//					}
				}
			}
		}
	}


	//��ȡDEM����
		private static void Dealelevationdata() {
			// TODO Auto-generated method stub
			//float[][] demdata = new float[718][1483];
	        try
	        {
	            Scanner scanner = new Scanner(new File("f://writerGDAL_aa.txt"));
	        	//Scanner scanner = new Scanner(new File("f://1000.txt"));
	            int i = 0;
	            while(scanner.hasNextLine())
	            {
	                String line = scanner.nextLine();
	                line = line.replace("[", "");
	                line = line.replace("]", "");
	                
	                String[] oneline = line.split(",");

	                for(int j = 0; j < oneline.length; j++)
	                {
	                    demdata[i][j] = Float.parseFloat(oneline[j]);
	                }
	                
	                i++;
	            }
	            scanner.close();
	            
	        }
	        catch(FileNotFoundException e)
	        {
	            e.printStackTrace();
	        }
			//return demdata;
	  
		}
		
}
