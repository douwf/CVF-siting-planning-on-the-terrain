package experiment1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/**
 * ��1000*1000�ĵ��ν��зֿ飬�ֳ�100��
 * ��ÿһ���зֱ����10������������
 * 
 * @author wyw
 *
 */

import javax.print.attribute.ResolutionSyntax;
import javax.print.attribute.Size2DSyntax;
public class Extrat_1000 {

	public static int M=1000,N=1000;
    public static float[][] demdata = new float[M][N];
    public static int[][] viewinfo = new int[M][N];
	public static int[][] VR = new int[M][N];
	public static int size = 32;
	
	public static List<int[]> featurepoint = new ArrayList<int[]>(); 
	public static float[] MAXMIN = new float[(M/size)*(M/size)*2];
	public static float first = 100,second = 200,p = (float) 0.5;
	public static float re = 5;
 	public static List<int[]> extract(){
		// TODO Auto-generated method stub

 		int[][] view = new int[M][N];
		//����DEM����
 		
		Dealelevationdata();

		//dealview();
		//��ȡ����������
		FeaturePoint();
		//�ֿ���ȡ����������
		/**
		 * ��ÿһ��ִ�еĲ����У�
		 * 1���ҳ��ÿ��и߳�ֵ�����VR������0�ĵ�
		 * 2�����õ���list�еĵ����ŷ�Ͼ���Ƚ�
		 *    ���������������ͽ��õ����list��
		 * ÿһ�����ĵ���ĿΪ10
		 */
		for(int i = 0;i < M/size;i++) {
			for(int j = 0;j < M/size;j++) {
				List<int[]> list  = partitionfind(i*size,j*size,size);
				featurepoint.addAll(list);
			}
		}
//		int s = 25;
//		for(int i = 0;i < 500/s;i++) {
//			for(int j = 0;j < N/s;j++) {
//				List<int[]> list  = partitionfind(i*s,j*s,s);
//				featurepoint.addAll(list);
//			}
//		}
//		int t = 50;
//		for(int i = 0;i < 500/t;i++) {
//			for(int j = 0;j < N/t;j++) {
//				List<int[]> list  = partitionfind(i*t+500,j*t,t);
//				featurepoint.addAll(list);
//			}
//		}
//		int[][] flag = new int[M][N];
//		for(int i = 0;i < M;i++) {
//			for(int j = 0;j < N;j++) {
//				flag[i][j] = 0;
//			}
//		}
//		while(featurepoint.size()<1000) {
//			float max = 0;
//			int tempx = 0,tempy = 0,flag1 = 0;
//			for(int i = 0;i < M;i++) {
//				for(int j = 0;j < N;j++) {
//					if(viewinfo[i][j]>max&&flag[i][j]==0) {
//						max = viewinfo[i][j];
//						tempx = i;
//						tempy = j;
//						
//					}
//				}
//			}
//			if(featurepoint.size()==0) {
//				int[] co = new int[2];
//				co[0] = tempx;
//				co[1] = tempy;
//				featurepoint.add(co);
//			}
//			for(int i = 0;i < featurepoint.size();i++) {
//				if(tempx>(featurepoint.get(i)[0]-20)&&tempx<(featurepoint.get(i)[0]+20)&&
//						tempy>(featurepoint.get(i)[1]-20)&&tempy<(featurepoint.get(i)[1]+20)) {
//					break;
//				}
//				if((i+1)==featurepoint.size()) {
//					flag1 = 1;
//				}
//			}
//			if(flag1 == 1) {
//				int[] co = new int[2];
//				co[0] = tempx;
//				co[1] = tempy;
//				featurepoint.add(co);
//			}
//			flag[tempx][tempy] = 1;
//		}
		
		
		return featurepoint;
	}

	
	private static void dealview() {
		// TODO Auto-generated method stub
		try
        {
            Scanner scanner = new Scanner(new File("F:\\experimentData\\view_1.txt"));

            int i = 0;
            while(scanner.hasNextLine())
            {
                String line = scanner.nextLine();
                String[] oneline = line.split(",");

                for(int j = 0; j < oneline.length; j++)
                {
                    viewinfo[i][j] = Integer.parseInt(oneline[j]);
                }
                
                i++;
            }
            scanner.close();
            
        }
        catch(FileNotFoundException e)
        {
            e.printStackTrace();
        }
	}


	private static List<int[]> partitionfind(int i, int j,int s) {
		// TODO Auto-generated method stub
		//���ڸÿ��ҳ�VR��Ϊ0�ĸ߳�ֵ��ߵ��ӵ�����
		List<int[]> currentlist = new ArrayList<int[]>();
		
		while(currentlist.size()<1) {
			int flag1 = 0,flag2 = 0;
			int[] coordinate = Compute(i, j, s);
			if(currentlist.size()==0) {
				currentlist.add(coordinate);
				VR[coordinate[0]][coordinate[1]] = 0;
			}
//			else {
//				for(int temp = 0;temp < currentlist.size();temp++) {
//					float distence = distence(coordinate[0],coordinate[1],demdata[coordinate[0]][coordinate[1]],
//							currentlist.get(temp)[0],currentlist.get(temp)[1],demdata[currentlist.get(temp)[0]][currentlist.get(temp)[1]]);
//					if(distence<=first) {
//						VR[coordinate[0]][coordinate[1]] = 0;
//						break;
//					}
//					else if(distence<=second&&distence>=first) {
//						flag1 = 1;
//					}
//					else if(distence>second){
//						flag2 = 1;
//						
//					}
//					if((temp+1) == currentlist.size()) {
//						if(flag1==1) {
//							float ram = (float) Math.random();
//							if(ram > p) {
//								currentlist.add(coordinate);
//								VR[coordinate[0]][coordinate[1]] = 0;
//							}
//						}
//						if(flag2==1&&flag1!=1) {
//							currentlist.add(coordinate);
//							VR[coordinate[0]][coordinate[1]] = 0;
//						}
//					}
//				}
//			}
		}
		
		return currentlist;
	}


	private static float distence(int i, int j, float h1, int k, int l, float h2) {
		// TODO Auto-generated method stub
		float distence = (float) Math.sqrt((i-k)*re*(i-k)*re+(j-l)*re*(j-l)*re+(h1-h2)*(h1-h2));
		return distence;
	}


	private static int[] Compute(int i, int j,int s) {
		// TODO Auto-generated method stub
		float max1 = -10,max2 = 0;

		int len1 = i+s,len2 = j+s;
		int tempx = 0,tempy = 0,temp1 = 0,temp2 = 0;
		for(;i < len1;i++) {
			for(int tempj = j;tempj < len2;tempj++) {
				if(demdata[i][tempj]>max1) {
					max1 = demdata[i][tempj];
					tempx = i;
					tempy = tempj;
				}
				
			}
		}
		int[] result = new int[2];
		if(tempx==0&&tempy==0) {
			result[0] = temp1;
			result[1] = temp2;
		}
		else {
			result[0] = tempx;
			result[1] = tempy;
		}
		
		return result;
	}


	private static void FeaturePoint() {
		// TODO Auto-generated method stub
		for(int i = 1;i < demdata.length;i++) {
			for(int j = 1;j < demdata[0].length;j++) {
				if(i!=0&&j!=0&&i!=demdata.length-1&&j!=demdata[0].length-1) {
					float center = demdata[i][j],N = demdata[i-1][j],S = demdata[i+1][j],
							W = demdata[i][j-1],E = demdata[i][j+1],
							NE = demdata[i-1][j+1],SE = demdata[i+1][j+1],
							WN = demdata[i-1][j-1],WS = demdata[i+1][j-1];
					if((W-center)*(E-center)>0) {
						if(E>center) VR[i][j] = -1;
						if(E<center) VR[i][j] = 1;
					}
					else if((S-center)*(N-center)>0) {
						if(N>center) VR[i][j] = -1;
						if(N<center) VR[i][j] = 1;
					}
//					if((E>center&&N<center)||(E<center&&N>center)){
//						VR[i][j] = 2;
//					}
					if(center>W&&center>N&&center>E&&center>S&&center>NE
							&&center>SE&&center>WN&&center>WS) {
						VR[i][j] = 3;
					}
					if(center<W&&center<N&&center<E&&center<S&&center<NE
							&&center<SE&&center<WN&&center<WS) {
						VR[i][j] = -2;
					}
//					if(center==W&&center==N&&center==E&&center==S&&center==NE
//							&&center==SE&&center==WN&&center==WS) {
//						VR[i][j] = 4;
//					}
				}
			}
		}
	}


	//��ȡDEM����
		private static void Dealelevationdata() {
			// TODO Auto-generated method stub

	        try
	        {
	            Scanner scanner = new Scanner(new File("F:\\experimentData\\1000_3_ex.txt"));

	            int i = 0;
	            while(scanner.hasNextLine())
	            {
	                String line = scanner.nextLine();
	                String[] oneline = line.split(",");

	                for(int j = 0; j < oneline.length; j++)
	                {
	                    demdata[i][j] = Float.parseFloat(oneline[j]);
	                }
	                
	                i++;
	            }
	            scanner.close();
	            
	        }
	        catch(FileNotFoundException e)
	        {
	            e.printStackTrace();
	        }
			//return demdata;
	  
		}
}
