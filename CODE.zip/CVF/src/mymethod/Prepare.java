package mymethod;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Prepare {

	static int M = 1000,N = 1000;
	static float[][] demdata = new float[M][N];
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		Dealelevationdata();
		BufferedWriter bw = new BufferedWriter(new FileWriter("F:\\experimentData\\view_1.txt"));
		int[][] view = new int[M][N];
		Compute compute = new Compute();
		for(int i = 0;i < M;i++) {
			for(int j = 0;j < N;j++) {
				int count = 0;
				int[][] temp = compute.computeView(i, j, demdata);
				for(int u = 0;u < M;u++) {
					for(int v = 0;v < N;v++) {
						if(temp[u][v] == 1) {
							count++;
						}
					}
				}
				view[i][j] = count;
				System.out.println(count);
			}
		}
		for(int i = 0;i < M;i++) {
			for(int j = 0;j < N;j++) {
				//�ѿ�����Ϣ�����ı��ļ���
			    String h = String.valueOf(view[i][j]);   
	            bw.write(h);
	            bw.write(",");  
			}
			bw.newLine();
            bw.flush();
		}
		bw.close();
	}
	
	private static void Dealelevationdata() {
		// TODO Auto-generated method stub

        try
        {
            Scanner scanner = new Scanner(new File("F:\\experimentData\\1000_1.txt"));

            int i = 0;
            while(scanner.hasNextLine())
            {
                String line = scanner.nextLine();
                String[] oneline = line.split(",");

                for(int j = 0; j < oneline.length; j++)
                {
                    demdata[i][j] = Float.parseFloat(oneline[j]);
                }
                
                i++;
            }
            scanner.close();
            
        }
        catch(FileNotFoundException e)
        {
            e.printStackTrace();
        }
		//return demdata;
  
	}

}
