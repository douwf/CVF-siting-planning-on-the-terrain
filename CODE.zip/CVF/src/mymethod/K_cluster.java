package mymethod;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/*
 * k_means����
 */
public class K_cluster {

	public static int number = 35;//�������
	public static List<float[]> center = new ArrayList<float[]>();//��������
	public static List<List<Integer>> clusters = new ArrayList<List<Integer>>();
	//public static float[][] demdata = Dealdata.ReadData();
	//public static List<int[]> point = TerrainFeature.Extract();
	public static float re = (float)5;
	
	//public static List<int[]> point = TerrainFeature.Extract();
	
//	public static void main(String[] args) throws IOException {
//		// TODO Auto-generated method stub
//		float[][] demdata = Dealdata.ReadData();
//		
//		//��ʼ�������point��ѡ��40������Ϊ��ʼ��������
//		for(int i = 0;i < number;i++) {
//			int temp =  (int) (Math.random()*point.size());
//			for(int j = 0;j < point.size();j++) {
//				if(temp == j) {
//					float[] p = new float[3];
//					p[0] = point.get(j)[0];
//					p[1] = point.get(j)[1];
//					p[2] = demdata[point.get(j)[0]][point.get(j)[1]];
//					
//					center.add(p);
//					//�Ѵ����ķ���ÿ�������λ
////					clusters.add(new ArrayList<Integer>());
////					clusters.get(i).add(point.get(j)[0]);
////					clusters.get(i).add(point.get(j)[1]);
//				}
//			}
//		}
//		
//		//K_means
//		KMeans(demdata,point);
//		//���
//		for(int i = 0;i < clusters.size();i++) {
//			for(int  j = 0;j < clusters.get(i).size();j+=2) {
//				System.out.print(clusters.get(i).get(j)+" "+clusters.get(i).get(j+1)+",");
//			}
//			System.out.println();
//		}
//		for(int i = 0;i < center.size();i++) {
//			System.out.print("{"+(int)center.get(i)[0]+","+(int)center.get(i)[1]+"}"+",");
//		}
//		
//	}
	
	
	public static List<List<Integer>> KM(float[][] demdata, List<int[]> point) {
		// TODO Auto-generated method stub
		//��ʼ�������point��ѡ��40������Ϊ��ʼ��������
		for(int i = 0;i < number;i++) {
			int temp =  (int) (Math.random()*point.size());
			for(int j = 0;j < point.size();j++) {
				if(temp == j) {
					float[] p = new float[3];
					p[0] = point.get(j)[0];
					p[1] = point.get(j)[1];
					p[2] = demdata[point.get(j)[0]][point.get(j)[1]];
					
					center.add(p);
					//�Ѵ����ķ���ÿ�������λ
//					clusters.add(new ArrayList<Integer>());
//					clusters.get(i).add(point.get(j)[0]);
//					clusters.get(i).add(point.get(j)[1]);
				}
			}
		}
		
		//K_means
		KMeans(demdata,point);
//		int flag = 0;
//		while(flag!=1) {
//			clusters.clear();
//			KMeans(demdata,point);
//			
//			for(int i = 0;i < clusters.size();i++) {
//				if((clusters.get(i).get(0)==0)&&(clusters.get(i).get(1)==0)) {
//					
//					break;
//				}
//				if((i+1)==clusters.size()) {
//					flag = 1;
//				}
//			}
//		}
		
		//���
		for(int i = 0;i < clusters.size();i++) {
			for(int  j = 0;j < clusters.get(i).size();j+=2) {
				System.out.print(clusters.get(i).get(j)+" "+clusters.get(i).get(j+1)+",");
			}
			System.out.println();
		}
		return clusters;
	}
	

	private static void KMeans(float[][] demdata, List<int[]> point) {
		// TODO Auto-generated method stub
		//���������Ĳ��ٸı�ʱ������ֹ
		List<List<Integer>> cluster = new ArrayList<List<Integer>>();
		int flag = 0;
		while(flag < 10000) {
			cluster.clear();
			for(int a = 0;a < center.size();a++) {
				cluster.add(new ArrayList<Integer>());
				//cluster.get(a).add((int)center.get(a)[0]);
				//cluster.get(a).add((int)center.get(a)[1]);
			}
			//��point�����е㶼��ÿ�������Ľ��бȽ�
			for(int i = 0;i < point.size();i++) {
				int row = point.get(i)[0];
				int col = point.get(i)[1];
				float min = comDistence((float)row,(float)col,demdata[row][col],center.get(0)[0],center.get(0)[1],center.get(0)[2]);
				int tempj = 0;
				for(int j = 0;j < center.size();j++) {
					//����õ㵽���ĵľ���
					float distence = comDistence((float)row,(float)col,demdata[row][col],center.get(j)[0],center.get(j)[1],center.get(j)[2]);
					if(distence<min) {
						min = distence;
						tempj = j;
					}
				}
				cluster.get(tempj).add(row);
				cluster.get(tempj).add(col);
			}
			//����ÿһ�ָ���������
			for(int x = 0;x < cluster.size();x++) {
				int sumrow = 0,sumcol = 0;
				float cenrow = 0,cencol = 0,sumheight = 0,cenheight = 0;
				for(int y = 0;y < cluster.get(x).size();y+=2) {
					sumrow += cluster.get(x).get(y);
					sumcol += cluster.get(x).get(y+1);
					sumheight += demdata[cluster.get(x).get(y)][cluster.get(x).get(y+1)];
				}
				cenrow = (float)sumrow/(float)(cluster.get(x).size()/2);
				cencol = (float)sumcol/(float)(cluster.get(x).size()/2);
				cenheight = sumheight/(float)(cluster.get(x).size()/2);
				float[] newcen = new float[3];
				newcen[0] = cenrow;
				newcen[1] = cencol;
				newcen[2] = cenheight;
				center.set(x, newcen);
			}
			flag++;
		}
		for(int i = 0;i < cluster.size();i++) {
			clusters.add(new ArrayList<Integer>());
			//�Ѵ����ĺʹ��ڵ㶼���뵽��������
			clusters.get(i).add((int)center.get(i)[0]);
			clusters.get(i).add((int)center.get(i)[1]);
			for(int j = 0;j < cluster.get(i).size();j++) {
				clusters.get(i).add(cluster.get(i).get(j));
			}
		}
	}

	private static float comDistence(float row, float col, float h1, float i, float j, float h2) {
		// TODO Auto-generated method stub
		float distence = (float) Math.sqrt((row-i)*re*(row-i)*re+(col-j)*re*(col-j)*re+(h1-h2)*(h1-h2));
		return distence;
	}

	

}
