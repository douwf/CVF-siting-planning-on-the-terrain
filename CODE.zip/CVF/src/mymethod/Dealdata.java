package mymethod;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Dealdata {
	
	public static int M = 1000,N = 1000;
	
	public static float[][] demdata = new float[M][N];

	public static float[][] ReadData() {
		// TODO Auto-generated method stub
		try {
			//Scanner scanner = new Scanner(new File("F:\\writerGDAL_aa.txt"));
			Scanner scanner = new Scanner(new File("F:\\experimentData\\1000_1_ex.txt"));
			int i = 0;
			while(scanner.hasNextLine()) {
				String line  = scanner.nextLine();
				//line = line.replace("[", "");
				//line = line.replace("]", "");
				String[] oneline = line.split(",");
				for(int j = 0;j < oneline.length;j++) {
					demdata[i][j] = Float.parseFloat(oneline[j]);
				}
				i++;
						
			}
			scanner.close();
		}
		catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		return demdata;
	}
}
