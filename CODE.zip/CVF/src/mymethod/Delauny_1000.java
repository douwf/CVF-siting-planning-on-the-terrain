package mymethod;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Delauny_1000 {

	private static int initialSize = 10000;     // Size of initial triangle
	public static ArrayList<ArrayList<Integer>> triangles = new ArrayList<ArrayList<Integer>>();
	public static ArrayList<ArrayList<Integer>> pointTotriangles = new ArrayList<ArrayList<Integer>>();//���������ӵ�������
    private static int threshold = 1;//��ֵ
	
	private static int d = 0;
	private static int l = 0;
	
	private static List<List<Integer>> clusters = new ArrayList<List<Integer>>();//��
	
	//public static List<int[]> feature = Extract_1000.extract();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		float[][] demdata = Dealdata.ReadData();
		ReadClusters();//��ȡ�������Ĵ�
		//��ȡ�����ӵ�Ŀ�����Ϣ

		int count = 0;
		for(int i = 0;i < clusters.size();i++) {
			for(int j = 2;j < clusters.get(i).size();j+=2) {
				count++;
			}
		}
		System.out.println(count);
		int[][] points = new int[clusters.size()][2];
		//�õ�clusters����
		for(int i = 0;i < clusters.size();i++) {
			points[i][0] = clusters.get(i).get(0);
			points[i][1] = clusters.get(i).get(1);
		}
		d(points);//�õ���������
		
		for(int i = 0;i < triangles.size();i++) {
			for(int j = 0;j < triangles.get(i).size();j++) {
				System.out.print(triangles.get(i).get(j)+",");
			}
			System.out.println();
		}
		
		for(int i = 0;i < points.length;i++) {
			//�ҳ��뵱ǰ�����ӵ����������Σ�����¼���б���
			int tempx = points[i][0];
			int tempy = points[i][1];
			pointTotriangles.add(new ArrayList<Integer>());
			pointTotriangles.get(i).add(tempx);
			pointTotriangles.get(i).add(tempy);
			for(int j = 0;j < triangles.size();j++) {
				for(int k = 0;k < triangles.get(j).size();k+=2) {//ֻҪ�����������������㣬�Ͱ���������μ��뵽�������б���
					if(tempx == triangles.get(j).get(k)&&tempy == triangles.get(j).get(k+1)) {
				
						for(int l = 0;l < triangles.get(j).size();l+=2) {
							if(l!=k) {
								pointTotriangles.get(i).add(triangles.get(j).get(l));
								pointTotriangles.get(i).add(triangles.get(j).get(l+1));
							}
						}
					}
				}
			}
		}
		
		//���������Ĵؽ��й��ˡ��ط���,�õ����ɸѡ�����ӵ�
		long time1 = System.currentTimeMillis();
		
		Deal(demdata);
		long time2 = System.currentTimeMillis();
		System.out.println(time2-time1);
		for(int i = 0;i < clusters.size();i++) {
			for(int j = 2;j < clusters.get(i).size();j+=2) {
				System.out.print("{"+clusters.get(i).get(j)+","+clusters.get(i).get(j+1)+"}"+",");
			}
		}
		
	}
			


	private static void Deal(float[][] demdata)  {
		// TODO Auto-generated method stub
		int flag = 0;
		
		while(flag == 0) {//���ÿ����δ������ֵҪ��
			//for(int d = 0;d < clusters.size();) {
				if(clusters.get(d).size()/2 > (threshold+1)) {
					//��d��Ҷ�ӽڵ��λ��
					int m = clusters.get(d).size()-2;
					int n = clusters.get(d).size()-1;
					//��d��Ҷ�ӽڵ��Ԫ��ֵ
					int a = clusters.get(d).get(m);
					int b = clusters.get(d).get(n);
					//����d�е�Ҷ�ӽڵ�Ӹô����Ƴ�
					clusters.get(d).remove(n);
					clusters.get(d).remove(m);
							
					loop:for(int j = 1;j <= clusters.size()-1;) {
						//if(d != j) {
							//�����d�е�Ҷ�ӽڵ����������е���Ӧ��
							//������ӵ�Ŀ�����ָ��
							l = (d+j)%(clusters.size());
							int flag0 = 0;
							for(int p = 2;p < pointTotriangles.get(d).size();p+=2) {
								if(pointTotriangles.get(d).get(p)==clusters.get(l).get(0)&&pointTotriangles.get(d).get(p+1)==clusters.get(l).get(1)) {
									break;
								}
								if((p+2)==pointTotriangles.get(d).size()) {
									flag0 = 1;
								}
							}
							if(flag0==1) {
								j++;
								continue;
							}
							
							int current_viewshed = compute_V(a, b, demdata);	
							//������ӵ���ظ�ָ��
							int current_overlap = compute_O(a, b, clusters.get(l),demdata);
							if(current_overlap == 0) {

								j++;
								continue;
							}
							//���и��ӵ��ָ��
							float current_indicator = (float)current_overlap/(float)(current_viewshed*current_viewshed);	
							
							//�Ƚϴ�d�е�Ҷ�ӽڵ��ڴ�j�е���Ӧ�����j�нڵ����Ӧ��
							int count = 0;
							for(int k = 2;k <=clusters.get(l).size()-1&&count<5;) {
								count++;
								int row = clusters.get(l).get(k);
								int col = clusters.get(l).get(k+1);
								//������ӵ�Ŀ�����ָ��
								
								int temp_viewshed = compute_V(row, col,demdata);	
								//������ӵ���ظ�ָ��
								int temp_overlap = compute_O(row, col, clusters.get(l),demdata);
								//���и��ӵ��ָ��
								float temp_indicator = (float)temp_overlap/(float)(temp_viewshed*temp_viewshed);
								
//								float temp_indicator = clusters.get(l).get(k+2);
								if(current_indicator < temp_indicator) {
									clusters.get(l).add(k,a);
									clusters.get(l).add(k+1,b);
									d = l;
									//sort(clusters.get(l),demdata);
									break loop;
								}
								k+=2;
							}
						j++;
						//�Դ�d��������
						//sort(clusters.get(d),demdata);
					}
					
				}
				else d = (d+1)%clusters.size();
				
				
				for(int i = 0;i < clusters.size();i++) {
					for(int j = 0;j < clusters.get(i).size();j+=2) {
						System.out.print(clusters.get(i).get(j)+" "+clusters.get(i).get(j+1)+",");
					}
					System.out.println();
				}
				
				//�ж�ÿ�����Ƿ�������ֵҪ����������flag��1
				for(int i = 0;i < clusters.size();i++) {
					if(clusters.get(i).size()/2 > (threshold+1)) {
						break;
					}
					if(i == clusters.size()-1) {
						flag = 1;
					}
				}
			}
			
		//}
	}

	private static void sort(List<Integer> cluster, float[][] demdata) {
		// TODO Auto-generated method stub
		int[] viewshednum = new int[cluster.size()/2-1];//�����Ÿô��и��ӵ�Ŀ�����ָ��
		int[] overlapnum = new int[cluster.size()/2-1];//��Ÿ��ӵ�����������ӵ�Ŀ������ص�
		float[] fitness = new float[cluster.size()/2-1];//��Ÿ��ӵ������ָ��
		for(int j = 2;j < cluster.size();j+=2) {
			//�����ӵ�Ŀ�����ָ��
			viewshednum[(j-2)/2] = 
					compute_V(cluster.get(j),cluster.get(j+1),demdata);
			//������ӵ���ĳһ���еĿ������ص�
			overlapnum[(j-2)/2] = 
					compute_O(cluster.get(j),cluster.get(j+1),cluster,demdata);

		}
		//�ô��и��ӵ������ָ������fitness[]
		for(int k = 2;k < cluster.size();k+=2) {
			fitness[(k-2)/2] = (float)overlapnum[(k-2)/2]/(float)(viewshednum[(k-2)/2]*viewshednum[(k-2)/2]);
		}
		
		
		//ð������
		for(int s = 0;s < fitness.length-1;s++) {
			for(int t = 0;t < fitness.length-1-s;t++) {
				if(fitness[t]>fitness[t+1]) {
					Swap(cluster,fitness,t,t+1);
				}
			}
			
		}
		
	}
	public static int compute_O(int i, int j, List<Integer> cluster, float[][] demdata) {
		// TODO Auto-generated method stub
		Compute compute = new Compute();
		int[][] view = compute.computeView(i, j, demdata);
		int[][] currentview = new int[view.length][view[0].length];
		for(int u = 0;u < view.length;u++) {
			for(int v = 0;v < view[0].length;v++) {
				currentview[u][v] = view[u][v];
			}
		}
		
		int count = 0;
		
		for(int k = 2;k < cluster.size();k+=2) {
			int a = cluster.get(k);
			int b = cluster.get(k+1);
			if(a!=i||b!=j) {
				int[][] tempview = compute.computeView(a, b, demdata); 
				for(int x = 0;x < currentview.length;x++)
					for(int y = 0;y < currentview[0].length;y++) {
						if(tempview[x][y] == 1&&currentview[x][y] == 1)
							count++;
					}
			}
		}
		return count;
	}

	public static int compute_V(int i, int j, float[][] demdata) {
		// TODO Auto-generated method stub
		Compute compute = new Compute();
		int[][] view = compute.computeView(i,j, demdata);
		
		int count = 0;
		
		for(int a = 0;a < view.length;a++)
			for(int b = 0;b < view[0].length;b++) {
				if(view[a][b] == 1) {
					count++;
				}
			}
		return count;
	}

	private static void Swap(List<Integer> list, float[] fitness, int s, int t) {
		// TODO Auto-generated method stub
		float temp = 0;
		int row = 0,col = 0;
		temp = fitness[s];
		
		fitness[s] = fitness[t];
		fitness[t] = temp;
		
		row = list.get(s*2+2);
		col = list.get(s*2+3);

		
		list.set(s*2+2, list.get(t*2+2));
		list.set(s*2+3, list.get(t*2+3));
		
		list.set(t*2+2, row);
		list.set(t*2+3, col);
		
	}

	public static void ReadClusters() {
		// TODO Auto-generated method stub
		try {
			Scanner scanner = new Scanner(new File("F:\\experimentData\\clusters_1ex_35.txt"));
			int i = 0;
			while(scanner.hasNextLine()) {
				String line  = scanner.nextLine();
				String[] oneline = line.split(",");
				clusters.add(new ArrayList<Integer>());
				for(int j = 0;j < oneline.length;j++) {
					clusters.get(i).add(Integer.parseInt(oneline[j]));
				}
				i++;
						
			}
			scanner.close();
		}
		catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		
	}

	
	
	public static ArrayList<ArrayList<Integer>> d(int[][] point) {
		// TODO Auto-generated method stub
		
		//temptriangles.add(new ArrayList<Float>());
		triangles.add(new ArrayList<Integer>());
		ArrayList<int[]> edgebuffer = new ArrayList<int[]>();//�߱�
		//�����������μ��뵽temptriangles�в����뵽triangles��
		int trianglecount = 0;
		
		triangles.get(trianglecount).add(-initialSize);
		triangles.get(trianglecount).add(-initialSize);
		triangles.get(trianglecount).add(initialSize);
		triangles.get(trianglecount).add(-initialSize);
		triangles.get(trianglecount).add(0);
		triangles.get(trianglecount).add(initialSize);
		for(int i = 0;i < point.length;i++) {
			//��ǰ������ĵ�
			int x = point[i][0];
			int y = point[i][1];
			edgebuffer.clear();
			//ArrayList<float[]> edgebuffer = new ArrayList<float[]>();//�߱�
			for(int j = 0;j < triangles.size();) {//����temptriangles��ÿһ��������
				//����������ε�Բ�ĺͰ뾶
				float[] circleraduis = computeCR(triangles.get(j).get(0),triangles.get(j).get(1),triangles.get(j).get(2),
						triangles.get(j).get(3),triangles.get(j).get(4),triangles.get(j).get(5));
				if(circleraduis[2] == 0) {
					triangles.remove(j);
					trianglecount--;
					continue;
				}
				//����õ������Բ�ڣ���������β���delaunny�����Σ������������ε����߱�����edgebuffer�У���temptrianglesȥ����������
				if(Math.sqrt((x-circleraduis[0])*(x-circleraduis[0])+(y-circleraduis[1])*(y-circleraduis[1]))<circleraduis[2]) {
					
					int x1 = triangles.get(j).get(0),y1 = triangles.get(j).get(1);
					int x2 = triangles.get(j).get(2),y2 = triangles.get(j).get(3);
					int x3 = triangles.get(j).get(4),y3 = triangles.get(j).get(5);
					//���������ε����߱�����edgebuffer��
					int[] edge1 = new int[4];
					edge1[0] = x1;edge1[1] = y1;edge1[2] = x2;edge1[3] = y2;
					edgebuffer.add(edge1);
					int[] edge2 = new int[4];
					edge2[0] = x1;edge2[1] = y1;edge2[2] = x3;edge2[3] = y3;
					edgebuffer.add(edge2);
					int[] edge3 = new int[4];
					edge3[0] = x2;edge3[1] = y2;edge3[2] = x3;edge3[3] = y3;
					edgebuffer.add(edge3);
					triangles.remove(j);
					trianglecount--;
				}
				else j++;
			}
			//��edgebuffer����ȥ��
			for(int l = 0;l < edgebuffer.size();) {
				for(int h = 0;h < edgebuffer.size();h++) {
					if(h!=l&&(edgebuffer.get(l)[0]==edgebuffer.get(h)[0]&&edgebuffer.get(l)[1]==edgebuffer.get(h)[1]
							||edgebuffer.get(l)[0]==edgebuffer.get(h)[2]&&edgebuffer.get(l)[1]==edgebuffer.get(h)[3])
							&&(edgebuffer.get(l)[2]==edgebuffer.get(h)[0]&&edgebuffer.get(l)[3]==edgebuffer.get(h)[1]
							||edgebuffer.get(l)[2]==edgebuffer.get(h)[2]&&edgebuffer.get(l)[3]==edgebuffer.get(h)[3])) {
						edgebuffer.remove(l);
						edgebuffer.remove(--h);
						break;
					}
					if((h+1) == edgebuffer.size()) {
						l++;
					}
				}
			}
			//��edge buffer�еı��뵱ǰ�ĵ������ϳ����������β�������temptriangles��
			for(int p = 0;p < edgebuffer.size();p++) {
				triangles.add(new ArrayList<Integer>());
				trianglecount++;
				triangles.get(trianglecount).add(x);
				triangles.get(trianglecount).add(y);
				triangles.get(trianglecount).add(edgebuffer.get(p)[0]);
				triangles.get(trianglecount).add(edgebuffer.get(p)[1]);
				triangles.get(trianglecount).add(edgebuffer.get(p)[2]);
				triangles.get(trianglecount).add(edgebuffer.get(p)[3]);
			} 
		}

		int count=0;
		for(int i = 0;i < triangles.size();i++) {
			for(int j = 0;j < triangles.get(i).size();j++) {
				System.out.print(triangles.get(i).get(j)+" ");
			}
			count++;
			System.out.println();
		}
		System.out.println(count);
		return triangles;
	}
	
	private static float[] computeCR(float x1, float y1, float x2, float y2, float x3, float y3) {
		// TODO Auto-generated method stub
		float[] info = new float[3];
		float a=(float) (((y2-y1)*(y3*y3-y1*y1+x3*x3-x1*x1)-(y3-y1)*(y2*y2-y1*y1+x2*x2-x1*x1))/(2.0*((x3-x1)*(y2-y1)-(x2-x1)*(y3-y1))));
		float b=(float) (((x2-x1)*(x3*x3-x1*x1+y3*y3-y1*y1)-(x3-x1)*(x2*x2-x1*x1+y2*y2-y1*y1))/(2.0*((y3-y1)*(x2-x1)-(y2-y1)*(x3-x1))));
		float r=(float) Math.sqrt((x1-a)*(x1-a)+(y1-b)*(y1-b));
		if(((x3-x1)*(y2-y1)-(x2-x1)*(y3-y1))==0||((y3-y1)*(x2-x1)-(y2-y1)*(x3-x1))==0) {
			info[0] = 0;
			info[1] = 0;
			info[2] = 0;
			return info;
		}
		else {
			info[0] = a;
			info[1] = b;
			info[2] = r;
			return info;
		}
		
	}

}
