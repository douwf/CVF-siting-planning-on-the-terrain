package mymethod;

public class Compute {

	private static float re = (float) 5;//����
	//private static float[][] demdata = Dealdata.ReadData();//�߳�����
	//private static int m = demdata.length,n = demdata[0].length;
    //private static int view[][] = new int[m][n];
	private static int R = 1000;//���Ӱ뾶
	
	int view[][] = new int[1000][1000];
	//���㵥���ӵ�Ŀ�����
	public int[][] computeView(int row, int col,float[][] demdata){
		//float[][] demdata = Dealdata.ReadData();//�߳�����
		int m = demdata.length,n = demdata[0].length;
		float[][] newdata = new float[m][n];
		for(int i=0;i<m;i++) {
			for(int j=0;j<n;j++) {
				newdata[i][j] = demdata[i][j];
			}
		}
		float R_altd = 0;
		int loop1,loop2;
		int counter = 0;
		float R1 = 0,R2 = 0;
		int flag = 0;
		//int view[][] = new int[m][n];
		

			/***	SE-E Sector
			 ***	The sector,which the outer loop is column and the inner loop is row,is a trangle sector.
			 ***	The area of row loop is from intial row to the diagnol,but if the column loop is larger than the row loop,we should control the row loop contained in the NROWS.
			 ***/
		for(loop2=col;loop2<demdata[0].length;loop2++,flag++)
			for(loop1=row;loop1<=loop2-col+row&&loop1<demdata.length;loop1++){
				if(loop1==row&&loop2==col){	//	view point,value is intialized 2
					view[loop1][loop2]=1;continue;
				}
				if(loop1==row||loop1-row==loop2-col){	//	line calculation
					if(loop1==row){	//	E axis,row aixs
						if(loop2==col+1&&distence(row,col,loop1,loop2,demdata[row][col],demdata[loop1][loop2])<R){	//	the first point is considered visible
							view[loop1][loop2]=1;counter++;continue;
						}
						else if(distence(row,col,loop1,loop2,demdata[row][col],demdata[loop1][loop2])<R){
							R_altd=newdata[loop1][loop2-1];
							view[loop1][loop2]=ISViewshed(demdata[row][col],demdata[loop1][loop2],R_altd);
							if(view[loop1][loop2]==0) {
								newdata[loop1][loop2] = R_altd;
							}
							else counter++;
						}
					}
					else{	// diagnol direction
						if(loop1==row+1&&distence(row,col,loop1,loop2,demdata[row][col],demdata[loop1][loop2])<R){
							view[loop1][loop2]=1;counter++;continue;
						}
						else if(distence(row,col,loop1,loop2,demdata[row][col],demdata[loop1][loop2])<R){
							R_altd=newdata[loop1-1][loop2-1];
							view[loop1][loop2]=ISViewshed(demdata[row][col],demdata[loop1][loop2],R_altd);
							if(view[loop1][loop2]==0) {
								newdata[loop1][loop2] = R_altd;
							}
							else counter++;
						}
					}
				}
				else if(distence(row,col,loop1,loop2,demdata[row][col],demdata[loop1][loop2])<R){
					R1=newdata[loop1-1][loop2-1];
					R2=newdata[loop1][loop2-1];
					R_altd=LineInterpolate(R1,R2);
					view[loop1][loop2]=ISViewshed(demdata[row][col],demdata[loop1][loop2],R_altd);
					if(view[loop1][loop2]==0) {
						newdata[loop1][loop2] = R_altd;
						//break;
					}
					else {
						counter++;
					}
				}
					
			}

			//	SE-S Sector
		flag = 0;
		for(loop1=row;loop1<demdata.length;loop1++,flag++)
			for(loop2=col;loop2<=col+(loop1-row)&&loop2<demdata[0].length;loop2++){
				if(loop1==row&&loop2==col)continue;	//	view point,value is intialized 2
				if(loop2==col||loop1-row==loop2-col)continue;
				else if(distence(row,col,loop1,loop2,demdata[row][col],demdata[loop1][loop2])<R){
					//R_row=float(i);R_col=col+(i-row)/k;
					R1=newdata[loop1-1][loop2];
					R2=newdata[loop1-1][loop2-1];
					R_altd=LineInterpolate(R1,R2);
					view[loop1][loop2]=ISViewshed(demdata[row][col],demdata[loop1][loop2],R_altd);
					if(view[loop1][loop2]==0) {
						newdata[loop1][loop2] = R_altd;
				    }
					else counter++;
				}
			}

			//	NE-E  Sector
		flag = 0;
		for(loop2=col;loop2<demdata[0].length;loop2++,flag++)
			for(loop1=row;loop1>=row-(loop2-col)&&loop1>=0;loop1--){
				if(loop1==row&&loop2==col)continue;	//	view point
				if(loop1==row||row-loop1==loop2-col)continue;
				else if(distence(row,col,loop1,loop2,demdata[row][col],demdata[loop1][loop2])<R){
					
					R1=newdata[loop1][loop2-1];
					R2=newdata[loop1+1][loop2-1];
					R_altd=LineInterpolate(R1,R2);
					view[loop1][loop2]=ISViewshed(demdata[row][col],demdata[loop1][loop2],R_altd);
					if(view[loop1][loop2]==0) {
						newdata[loop1][loop2] = R_altd;
						
					}
					else counter++;
				}
						
			}

			//	NE-N Sector
		flag = 0;
		for(loop1=row;loop1>=0;loop1--,flag++)
			for(loop2=col;loop2<=(row-loop1)+col&&loop2<demdata[0].length;loop2++){
				if(loop1==row&&loop2==col)continue;	//	view point
				if(loop2==col||row-loop1==loop2-col){	//	line calculation�����������ϵ�Ŀ����Լ���
					if(loop2==col){	//	N axis,column aixs N����
						if(loop1==row-1&&distence(row,col,loop1,loop2,demdata[row][col],demdata[loop1][loop2])<R){
							view[loop1][loop2]=1;counter++;continue;
						}
						else if(distence(row,col,loop1,loop2,demdata[row][col],demdata[loop1][loop2])<R){
							R_altd=newdata[loop1][loop2];
							view[loop1][loop2]=ISViewshed(demdata[row][col],demdata[loop1][loop2],R_altd);
							if(view[loop1][loop2]==0&&loop1!=0) {
								newdata[loop1][loop2] = demdata[loop1-1][loop2];
							}
							else counter++;
						}
					}
					else{	// diagnol direction NE����
						if(loop1==row-1&&distence(row,col,loop1,loop2,demdata[row][col],demdata[loop1][loop2])<R){
							view[loop1][loop2]=1;counter++;continue;
						}
						else if(distence(row,col,loop1,loop2,demdata[row][col],demdata[loop1][loop2])<R){
							R_altd=newdata[loop1][loop2];
							view[loop1][loop2]=ISViewshed(demdata[row][col],demdata[loop1][loop2],R_altd);
							if(view[loop1][loop2]==0) {
								newdata[loop1][loop2] = demdata[loop1+1][loop2-1];
								
							}
							else counter++;
						}
					}
					//if(view[loop1][loop2]==1)counter++;
				}
				else if(distence(row,col,loop1,loop2,demdata[row][col],demdata[loop1][loop2])<R){
					R1=newdata[loop1+1][loop2-1];
					R2=newdata[loop1+1][loop2];
					R_altd=LineInterpolate(R1,R2);
					view[loop1][loop2]=ISViewshed(demdata[row][col],demdata[loop1][loop2],R_altd);
					if(view[loop1][loop2]==0) {
						newdata[loop1][loop2] = R_altd;
						//break;
					}
					else {
						counter++;
					}
				}
			}

			//	NW-N Sector
		flag = 0;
		for(loop1=row;loop1>=0;loop1--,flag++)
			for(loop2=col;loop2>=col-(row-loop1)&&loop2>=0;loop2--){
				if(loop1==row&&loop2==col)continue;	//	view point
				if(loop2==col||row-loop1==col-loop2)continue;
				else if(distence(row,col,loop1,loop2,demdata[row][col],demdata[loop1][loop2])<R){
					
					//R_row=float(i);R.f_col=col-(row-i)/k;
					R1=newdata[loop1+1][loop2];
					R2=newdata[loop1+1][loop2+1];
					R_altd=LineInterpolate(R1,R2);
					view[loop1][loop2]=ISViewshed(demdata[row][col],demdata[loop1][loop2],R_altd);
					if(view[loop1][loop2]==0) {
						newdata[loop1][loop2] = R_altd;
					}
					else counter++;
				}
						
			}

			//	NW-W Sector
		flag = 0;
		for(loop2=col;loop2>=0;loop2--,flag++)
			for(loop1=row;loop1>=row-(col-loop2)&&loop1>=0;loop1--){
				if(loop1==row&&loop2==col)continue;	//	view point
				if(loop1==row||row-loop1==col-loop2){	//	line calculation
					if(loop1==row){	//	W axis,row aixs
						if(loop2==col-1&&distence(row,col,loop1,loop2,demdata[row][col],demdata[loop1][loop2])<R){
							view[loop1][loop2]=1;counter++;continue;
						}
						else if(distence(row,col,loop1,loop2,demdata[row][col],demdata[loop1][loop2])<R){
							//R_row=float(i);R.f_col=float(j);
							R_altd=newdata[loop1][loop2+1];
							view[loop1][loop2]=ISViewshed(demdata[row][col],demdata[loop1][loop2],R_altd);
							if(view[loop1][loop2]==0) {
								newdata[loop1][loop2] = R_altd;
							}
						}
					}
					else{	// diagnol direction
						if(loop1==row-1&&distence(row,col,loop1,loop2,demdata[row][col],demdata[loop1][loop2])<R){
							view[loop1][loop2]=1;counter++;continue;
						}
						else if( distence(row,col,loop1,loop2,demdata[row][col],demdata[loop1][loop2])<R){
							//R.f_col=float(j);R.f_row=float(i);
							R_altd=newdata[loop1+1][loop2+1];
							view[loop1][loop2]=ISViewshed(demdata[row][col],demdata[loop1][loop2],R_altd);
							if(view[loop1][loop2]==0) {
								newdata[loop1][loop2] = R_altd;
							}
							else counter++;
						}
					}
					
				}
				else if(distence(row,col,loop1,loop2,demdata[row][col],demdata[loop1][loop2])<R){
					
			    	//R_row=row-(col-j)/k;R.f_col=float(j);
					R1=newdata[loop1][loop2+1];
					R2=newdata[loop1+1][loop2+1];
					R_altd=LineInterpolate(R1,R2);
					view[loop1][loop2]=ISViewshed(demdata[row][col],demdata[loop1][loop2],R_altd);
					if(view[loop1][loop2]==0) {
							newdata[loop1][loop2] = R_altd;
					}
					else counter++;
				}
					
			}

			//	SW-W Sector
		flag = 0;
		for(loop2=col;loop2>=0&&flag<=R;loop2--,flag++)
			for(loop1=row;loop1<=row+(col-loop2)&&loop1<demdata.length;loop1++){
				if(loop1==row&&loop2==col)continue;	//	view point
				if(loop1==row||loop1-row==col-loop2)continue;
				else if(distence(row,col,loop1,loop2,demdata[row][col],demdata[loop1][loop2])<R){
					//R.f_row=row+(col-j)/k;R.f_col=float(j);
					R1=newdata[loop1][loop2+1];
					R2=newdata[loop1-1][loop2+1];
					R_altd=LineInterpolate(R1,R2);
					view[loop1][loop2]=ISViewshed(demdata[row][col],demdata[loop1][loop2],R_altd);
					if(view[loop1][loop2]==0) {
						newdata[loop1][loop2] = R_altd;
							
					}
					else counter++;
				}
			}

			//	SW-S Sector
		flag = 0;
		for(loop1=row;loop1<demdata.length&&flag<=R;loop1++,flag++)
			for(loop2=col;loop2>=col-(loop1-row)&&loop2>=0;loop2--){
				if(loop1==row&&loop2==col)continue;	//	view point
				if(loop2==col||loop1-row==col-loop2){	//	line calculation
					if(loop2==col){	//	S axis,column aixs
						if(loop1==row+1&&distence(row,col,loop1,loop2,demdata[row][col],demdata[loop1][loop2])<R){
							view[loop1][loop2]=1;counter++;continue;
						}
						else if(distence(row,col,loop1,loop2,demdata[row][col],demdata[loop1][loop2])<R){
							//R.f_row=float(i);R.f_col=float(j);
							R_altd=newdata[loop1-1][loop2];
							view[loop1][loop2]=ISViewshed(demdata[row][col],demdata[loop1][loop2],R_altd);
							if(view[loop1][loop2]==0) {
								newdata[loop1][loop2] = R_altd;
							}
							else counter++;
						}
					}
					else{	// diagnol direction
						if(loop1==row+1&&distence(row,col,loop1,loop2,demdata[row][col],demdata[loop1][loop2])<R){
							view[loop1][loop2]=1;counter++;continue;
						}
						else if(distence(row,col,loop1,loop2,demdata[row][col],demdata[loop1][loop2])<R){
							//R.f_col=float(j);R.f_row=float(i);
							R_altd=newdata[loop1-1][loop2+1];
							view[loop1][loop2]=ISViewshed(demdata[row][col],demdata[loop1][loop2],R_altd);
							if(view[loop1][loop2]==0) {
								newdata[loop1][loop2] = R_altd;
							}
							else counter++;
						}
					}
					
				}
				else if( distence(row,col,loop1,loop2,demdata[row][col],demdata[loop1][loop2])<R){
					//R.f_row=float(i);R.f_col=col-(i-row)/k;
					R1=newdata[loop1-1][loop2];
					R2=newdata[loop1-1][loop2+1];
					R_altd=LineInterpolate(R1,R2);
					view[loop1][loop2]=ISViewshed(demdata[row][col],demdata[loop1][loop2],R_altd);
					if(view[loop1][loop2]==0) {
						newdata[loop1][loop2] = R_altd;
					}
					else counter++;
				}
			}
		//System.out.println(counter);
		return view;
	}
	
	private static float distence(int row, int col, int loop1, int loop2, float viewh, float targeth) {
		// TODO Auto-generated method stub
		float dis = 0;
		dis = (float) Math.sqrt((loop2-col)*re*(loop2-col)*re
				+(loop1-row)*re*(loop1-row)*re
				+(viewh-targeth)*(viewh-targeth));
		return dis;
	}

	private static float LineInterpolate(float r1, float r2) {
		// TODO Auto-generated method stub
		
		return (r1+r2)/2;
	}
	private static int ISViewshed(float f, float g, float r_altd) {
		// TODO Auto-generated method stub
		if((g-f)/(r_altd-f)>=1)
			
		    return 1;
		else return 0;
	}

}
